-- =====================================================================
-- DevFlow - esquema de referência (MySQL 8.0.16+)
--
-- A aplicação cria/atualiza as tabelas automaticamente via Hibernate
-- (spring.jpa.hibernate.ddl-auto=update). Este arquivo documenta o modelo
-- e pode ser usado para criar o banco manualmente ou como base para
-- migrações Flyway. Diferenças em relação ao Hibernate: aqui os FKs de
-- exclusão em cascata e os CHECKs estão explícitos.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS devflow CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE devflow;

-- ---------------------------------------------------------------------
-- Usuários (exclusão lógica pela coluna "active")
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(150) NOT NULL,
    password    VARCHAR(255) NOT NULL,                       -- hash BCrypt
    role        ENUM('USER', 'ADMIN') NOT NULL DEFAULT 'USER',
    active      BIT(1)       NOT NULL DEFAULT b'1',
    created_at  DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at  DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT uk_users_email UNIQUE (email)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- Projetos
-- ---------------------------------------------------------------------
CREATE TABLE projects (
    id          BIGINT       NOT NULL AUTO_INCREMENT,
    name        VARCHAR(120) NOT NULL,
    description VARCHAR(2000),
    status      ENUM('PLANEJADO', 'EM_ANDAMENTO', 'PAUSADO', 'CONCLUIDO') NOT NULL DEFAULT 'PLANEJADO',
    deadline    DATE,
    owner_id    BIGINT       NOT NULL,
    created_at  DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at  DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_projects_owner FOREIGN KEY (owner_id) REFERENCES users (id),
    INDEX idx_projects_status (status),
    INDEX idx_projects_owner (owner_id)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- Membros do projeto (relacionamento N:N entre users e projects)
-- ---------------------------------------------------------------------
CREATE TABLE project_members (
    id          BIGINT      NOT NULL AUTO_INCREMENT,
    project_id  BIGINT      NOT NULL,
    user_id     BIGINT      NOT NULL,
    role        ENUM('OWNER', 'MEMBER') NOT NULL DEFAULT 'MEMBER',
    joined_at   DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT uk_project_member UNIQUE (project_id, user_id),   -- sem membro duplicado
    CONSTRAINT fk_project_members_project FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE,
    CONSTRAINT fk_project_members_user FOREIGN KEY (user_id) REFERENCES users (id),
    INDEX idx_project_members_user (user_id)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- Tarefas
-- ---------------------------------------------------------------------
CREATE TABLE tasks (
    id            BIGINT       NOT NULL AUTO_INCREMENT,
    title         VARCHAR(200) NOT NULL,
    description   VARCHAR(2000),
    status        ENUM('TODO', 'EM_ANDAMENTO', 'EM_REVISAO', 'CONCLUIDA') NOT NULL DEFAULT 'TODO',
    priority      ENUM('BAIXA', 'MEDIA', 'ALTA', 'URGENTE') NOT NULL DEFAULT 'MEDIA',
    project_id    BIGINT       NOT NULL,
    assignee_id   BIGINT,                                         -- responsável (opcional)
    created_by_id BIGINT       NOT NULL,
    deadline      DATE,
    completed_at  DATETIME(6),
    created_at    DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at    DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_tasks_project FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE,
    CONSTRAINT fk_tasks_assignee FOREIGN KEY (assignee_id) REFERENCES users (id),
    CONSTRAINT fk_tasks_created_by FOREIGN KEY (created_by_id) REFERENCES users (id),
    -- tarefa concluída tem data de conclusão e responsável; as demais não têm data de conclusão
    CONSTRAINT chk_tasks_completion CHECK (
        (status = 'CONCLUIDA' AND completed_at IS NOT NULL AND assignee_id IS NOT NULL)
        OR (status <> 'CONCLUIDA' AND completed_at IS NULL)
    ),
    INDEX idx_tasks_project (project_id),
    INDEX idx_tasks_assignee (assignee_id),
    INDEX idx_tasks_status (status),
    INDEX idx_tasks_deadline (deadline)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- Tags e relacionamento N:N com tarefas
-- ---------------------------------------------------------------------
CREATE TABLE tags (
    id    BIGINT      NOT NULL AUTO_INCREMENT,
    name  VARCHAR(30) NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT uk_tags_name UNIQUE (name)
) ENGINE = InnoDB;

CREATE TABLE task_tags (
    task_id BIGINT NOT NULL,
    tag_id  BIGINT NOT NULL,
    PRIMARY KEY (task_id, tag_id),
    CONSTRAINT fk_task_tags_task FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE CASCADE,
    CONSTRAINT fk_task_tags_tag FOREIGN KEY (tag_id) REFERENCES tags (id)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- Comentários
-- ---------------------------------------------------------------------
CREATE TABLE comments (
    id          BIGINT        NOT NULL AUTO_INCREMENT,
    content     VARCHAR(2000) NOT NULL,
    author_id   BIGINT        NOT NULL,
    task_id     BIGINT        NOT NULL,
    created_at  DATETIME(6)   NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_comments_author FOREIGN KEY (author_id) REFERENCES users (id),
    CONSTRAINT fk_comments_task FOREIGN KEY (task_id) REFERENCES tasks (id) ON DELETE CASCADE,
    INDEX idx_comments_task (task_id)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
-- Atividades (auditoria)
-- project_id e task_id NÃO têm FK de propósito: o histórico deve
-- continuar existindo mesmo depois que o projeto/tarefa forem excluídos.
-- ---------------------------------------------------------------------
CREATE TABLE activities (
    id             BIGINT       NOT NULL AUTO_INCREMENT,
    activity_type  VARCHAR(40)  NOT NULL,
    description    VARCHAR(500) NOT NULL,
    user_id        BIGINT       NOT NULL,
    project_id     BIGINT,
    task_id        BIGINT,
    created_at     DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    CONSTRAINT fk_activities_user FOREIGN KEY (user_id) REFERENCES users (id),
    INDEX idx_activities_user (user_id),
    INDEX idx_activities_project (project_id),
    INDEX idx_activities_created (created_at)
) ENGINE = InnoDB;
